options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, fig.height = 5)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(dplyr)
library(spData)

world = world %>% select(name_long, continent, region_un, pop, area_km2)
# glimpse(world)
world 

world %>% 
  rename(name = name_long)

world %>% 
  mutate(pop_dens = pop / area_km2)

world_sum = world %>% 
  summarize(pop = sum(pop, na.rm = TRUE), n = n())
world_sum

world_agg = world %>%
  group_by(continent) %>%
  summarize(pop = sum(pop, na.rm = TRUE))
world_agg

world_df = st_drop_geometry(world_agg)
class(world_df)

library(raster)
library(spData)
library(spDataLarge)

# getValues(elevation)
elevation[]

elevation7 = elevation
elevation7[1:200, 1:300] = NA
plot(elevation7)

elevation8 = elevation7
elevation8[is.na(elevation8)] = 9999
plot(elevation8)

cellStats(elevation, sd)
cellStats(elevation, mean)
summary(elevation)

nlcd
freq(nlcd)

## # 1
## world_pop_dens = world %>%
##   mutate(pop_dens = pop/area_km2)
## 
## world_pop_dens %>%
##   arrange(-pop_dens) %>%
##   slice(1:5) %>%
##   dplyr::select(name_long, pop_dens)
## 
## # 2
## world_pop_dens_g = world_pop_dens %>%
##   summarise(dens_avg = mean(pop_dens, na.rm = TRUE))
## world_pop_dens_c = world_pop_dens %>%
##   group_by(continent) %>%
##   summarize(dens_avg = mean(pop_dens, na.rm = TRUE))
## 
## # 3
## library(tmap)
## tm1 = tm_shape(world_pop_dens) + tm_polygons("pop_dens")
## tm2 = tm_shape(world_pop_dens_c) + tm_polygons("dens_avg")
## tm3 = tm_shape(world_pop_dens_g) + tm_polygons("dens_avg")
## 
## tmap_arrange(tm1, tm2, tm3)
## 
## #4
## nz_elev
## 
## cellStats(nz_elev, min)
## cellStats(nz_elev, max)
## cellStats(nz_elev, mean)
## 
## #5
## nz_elev2 = nz_elev
## nz_elev2[nz_elev2 > 2000 & nz_elev2 < 3000] = NA
## cellStats(nz_elev2, min)
## cellStats(nz_elev2, max)
## cellStats(nz_elev2, mean)
## 
## #6
## plot(nlcd)
## 
## nlcd[nlcd == 8] = 1
## plot(nlcd)
