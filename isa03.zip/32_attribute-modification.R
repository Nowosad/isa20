library(sf)
library(dplyr)
library(spData)

world = world %>% select(name_long, continent, region_un, pop, area_km2)
# glimpse(world)
world 

world %>% 
  rename(name = name_long)

world %>% 
  mutate(pop_dens = pop / area_km2)

world_sum = world %>% 
  summarize(pop = sum(pop, na.rm = TRUE), n = n())
world_sum

world_agg = world %>%
  group_by(continent) %>%
  summarize(pop = sum(pop, na.rm = TRUE))
world_agg

world_df = st_drop_geometry(world_agg)
class(world_df)

library(raster)
library(spData)
library(spDataLarge)

# getValues(elevation)
elevation[]

elevation7 = elevation
elevation7[1:200, 1:300] = NA
plot(elevation7)

elevation8 = elevation7
elevation8[is.na(elevation8)] = 9999
plot(elevation8)

cellStats(elevation, sd)
cellStats(elevation, mean)
summary(elevation)

nlcd
freq(nlcd)
