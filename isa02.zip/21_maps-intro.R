library(sf)
library(tmap)
library(spData)

tm_shape(nz) + 
  tm_fill()

tm_shape(nz) + 
  tm_borders()

tm_shape(nz) +
  tm_fill() +
  tm_borders() 

tm_shape(nz) +
  tm_polygons()

tm_shape(nz) +
  tm_fill(col = "blue") +
  tm_borders()

tm_shape(nz) +
  tm_fill(col = "#00247D") +
  tm_borders()

tm_shape(nz) +
  tm_fill(col = "#00247D", alpha = 0.2) +
  tm_borders(col = "#CC142B")

tm_shape(nz) +
  tm_fill(col = "#00247D", alpha = 0.2) +
  tm_borders(col = "#CC142B", lwd = 2)

nz

tm_shape(nz) + 
  tm_polygons(col = "Median_income")

tm_shape(nz) + 
  tm_polygons(col = "Median_income",
              title = "Median Income (NZD):")

tm_shape(nz) + 
  tm_polygons(col = "Median_income", 
              n = 6)

tm_shape(nz) + 
  tm_polygons(col = "Median_income",
              breaks = c(20000, 25000, 30000, 35000))

tm_shape(nz) +
  tm_polygons(col = "Median_income", 
              #style = "fixed",
              breaks = c(20000, 25000, 30000, 35000),
              labels = c("low", "medium", "high"))

tm_shape(nz) + 
  tm_polygons(col = "Median_income", legend.hist = TRUE)

tm_shape(nz) + 
  tm_polygons(col = "Median_income",
              style = "cont")

tm_shape(nz) + 
  tm_polygons(col = "Median_income",
              style = "order")

world_moll = st_transform(world, crs = "+proj=moll")
tm_shape(world_moll) +
  tm_polygons(col = "pop")

tm_shape(world_moll) +
  tm_polygons(col = "pop", 
              style = "order")

tm_shape(world_moll) +
  tm_polygons(col = "pop", 
              style = "log10_pretty")

tm_shape(world_moll) +
  tm_polygons(col = "pop", 
              style = "log10")

tm1 = tm_shape(world_moll) +
  tm_polygons(col = "pop")

tm2 = tm_shape(world_moll) +
  tm_polygons(col = "pop", 
              style = "log10_pretty")

tmap_arrange(tm1, tm2, nrow = 1)

nz

tm_shape(nz) +
  tm_polygons(col = "Island")

tm_shape(nz) +
  tm_polygons(col = "Name")

## tmaptools::palette_explorer()

tm_shape(nz) +
  tm_polygons(col = "Island")

tm_shape(nz) +
  tm_polygons(col = "Island",
              palette = "Set2")

tm_shape(nz) +
  tm_polygons(col = "Island",
              palette = "-Set2")

tm_shape(nz) +
  tm_polygons(col = "Island",
              palette = c("blue", "orange"))

tm_shape(nz) + 
  tm_polygons(col = "Median_income")

tm_shape(nz) + 
  tm_polygons(col = "Median_income", 
              palette = "Blues")

tm_shape(nz) + 
  tm_polygons(col = "Median_income", 
              palette = "Greens")

min(nz$Median_income)
mean(nz$Median_income)
max(nz$Median_income)

my_breaks = c(min(nz$Median_income), 
              mean(nz$Median_income) - 1000,
              mean(nz$Median_income) + 1000,
              max(nz$Median_income))

tm_shape(nz) + 
  tm_polygons(col = "Median_income", 
              breaks = my_breaks,
              palette = "RdYlGn")

tm_shape(nz) + 
  tm_polygons(col = "Median_income", 
              midpoint = mean(nz$Median_income),
              palette = "RdYlGn")

library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

## library(sf)
## library(tmap)
## library(spData)
## library(dplyr)
## us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))
## # 1
## tm_shape(us_states) +
##   tm_polygons(col = "#821433",
##               lwd = 3)
## # 2
## tm_shape(us_states) +
##   tm_polygons(col = "median_income_15",
##               style = "jenks",
##               palette = rcartocolor::carto_pal(5, "Emrld"))
## 
## # https://geocompr.github.io/post/
## # 3
## tm_shape(us_states) +
##   tm_polygons(col = "REGION",
##               title = "Region: ")
## # 4
## tm_shape(us_states) +
##   tm_polygons(col = "median_income_15",
##               midpoint = mean(us_states$median_income_15),
##               palette = "RdYlGn")
