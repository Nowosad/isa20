library(sf)
library(raster)
library(tmap)
library(spData)

tm_shape(nz) +
  tm_polygons() +
  tm_text(text = "Name")

tm_shape(nz) +
  tm_polygons() +
  tm_text(text = "Name", size = "AREA", root = 2)

tm_shape(nz) + 
  tm_polygons() +
  tm_grid()

tm_shape(nz) + 
  tm_polygons() +
  tm_graticules()

tm_shape(nz) + 
  tm_graticules() +
  tm_polygons()

tm_shape(elev) +
  tm_raster(legend.show = FALSE) + 
  tm_graticules(lines = FALSE)

tm_shape(nz) +
  tm_polygons() +
  tm_scale_bar() 

tm_shape(nz) +
  tm_polygons() +
  tm_scale_bar(breaks = c(0, 100, 200), size = 1) 

tm_shape(nz) +
  tm_polygons() +
  tm_scale_bar(breaks = c(0, 100, 200), size = 1) +
  tm_compass(position = c("LEFT", "top"), type = "rose", size = 2) 

tm_shape(nz) +
  tm_polygons() +
  tm_scale_bar(breaks = c(0, 100, 200), size = 1) +
  tm_compass(position = c("LEFT", "top"), type = "rose", size = 2) +
  tm_logo("https://www.r-project.org/logo/Rlogo.png", height = 2)

tm_shape(nz) +
  tm_polygons() +
  tm_scale_bar(breaks = c(0, 100, 200), size = 1) +
  tm_compass(position = c("LEFT", "top"), type = "rose", size = 2) +
  tm_logo("https://www.r-project.org/logo/Rlogo.png", height = 2) +
  tm_credits("J. Nowosad, 2020")

tm_shape(nz) +
  tm_polygons() +
  tm_layout(title = "New Zealand")

tm_shape(nz) +
  tm_polygons() +
  tm_layout(title = "New Zealand",
            scale = 0.5)

tm_shape(nz) +
  tm_polygons() +
  tm_layout(main.title = "New Zealand")

tm_shape(nz) +
  tm_polygons() +
  tm_layout(main.title = "New Zealand",
            frame = FALSE)

tm_shape(nz) +
  tm_polygons() +
  tm_layout(main.title = "New Zealand",
            bg.color = "lightblue")

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(inner.margins = c(0.1, 0.1, 0.1, 0.3))

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(legend.position = c("LEFT", "TOP"))

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(legend.outside = TRUE)

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(legend.show = FALSE)

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_style("bw")

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_style("classic")

## tmap_style_catalogue()

library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))
