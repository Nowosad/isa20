options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, fig.height = 5)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(tmap)
library(spData)
tm_shape(nz) +
  tm_polygons()

tmap_mode("view")
tm_shape(nz) +
  tm_polygons()

tmap_mode("plot")
tm_shape(nz) +
  tm_polygons()

library(leaflet)
tmap_mode("view")
tm_shape(nz) +
  tm_polygons() + 
  tm_basemap(server = "OpenTopoMap") +
  tm_minimap()

mapview::mapview(nz) + nz_height

tm1 = tm_shape(nz) +
  tm_polygons()
tm1

tmap_save(tm1,
          filename = "my_map.png",
          width = 4,
          height = 6,
          asp = 0)

tmap_save(tm1, 
          filename = "my_map.html")
