## library(sf)
## url = "https://www.naturalearthdata.com/http//www.naturalearthdata.com/download/110m/physical/ne_110m_coastline.zip"
## dir.create("data")
## download.file(url = url,
##               destfile = "ne_110m_coastline.zip")
## unzip(zipfile = "ne_110m_coastline.zip", exdir = "data")
## coastline = st_read("data/ne_110m_coastline.shp")
## file.remove("ne_110m_coastline.zip")

library(rnaturalearth)
library(sp)
coastline2 = ne_download(scale = 110, 
                         type = "coastline", 
                         category = "physical")
plot(coastline2)

library(sf)
class(coastline2)
usa_sf = st_as_sf(coastline2)
class(coastline2)

coastline3 = ne_download(scale = 110,
                         type = "coastline",
                         category = "physical",
                         returnclass = "sf")
plot(coastline3)

coastline4 = ne_download(scale = 10,
                         type = "coastline",
                         category = "physical",
                         returnclass = "sf")
plot(coastline4)

uk = ne_countries(country = "United Kingdom",
                  returnclass = "sf") 
uk2 = ne_countries(country = "United Kingdom",
                   type = "map_units",
                   returnclass = "sf") 
scotland = uk2 %>% 
  dplyr::filter(subunit == "Scotland")





uk3 = ne_countries(scale = 10, 
                   country = "United Kingdom",
                   type = "map_units",
                   returnclass = "sf") 
scotland2 = uk3 %>% 
  dplyr::filter(subunit == "Scotland")





library(osmdata)
parks = opq(bbox = "glasgow uk") %>% 
  add_osm_feature(key = "leisure", value = "park") %>% 
  osmdata_sf()
parks

parks$osm_polygons

## parks$osm_polygons



bb = st_bbox(c(xmin = -4.4, xmax = -4, ymax = 55.7, ymin = 56),
             crs = st_crs(4326))
water = opq(bb) %>%
  add_osm_feature(key = "natural", value = "water") %>% 
  osmdata_sf()
water

library(raster)
elev = getData("SRTM", lon = -4, lat = 56)

worldclim1 = getData("worldclim", var = "tmax", res = 0.5, lon = -4, lat = 56)

worldclim2 = getData("worldclim", var = "bio", res = 0.5, lon = -4, lat = 56)

# install.packages("rgbif")
library(rgbif)
bison_search = occ_search(scientificName = "Bison bonasus",
                         hasCoordinate = TRUE,
                         limit = 10)
bison_data_gbif = occ_search(scientificName = "Bison bonasus",
                         hasCoordinate = TRUE,
                         limit = 300)
bison_data = bison_data_gbif$data
bison_data_sf = st_as_sf(bison_data,
                      coords = c("decimalLongitude", "decimalLatitude"))





# install.packages("rLandsat")
library(rLandsat)
# data(world_rowpath)
result = landsat_search(min_date = "2018-01-01",
                        max_date = "2018-01-16",
                        country = "United Kingdom of Great Britain and Northern Ireland")

result
