library(sf)
library(spData)
nz_height

## st_write(obj = nz_height, dsn = "nz_height.gpkg")

## st_write(obj = nz_height, dsn = "nz_height.gpkg")

## st_write(obj = nz_height, dsn = "nz_height.csv", layer_options = "GEOMETRY=AS_XY")

## nz_height_coords = as.data.frame(st_coordinates(nz_height))
## nz_height2 = dplyr::bind_cols(nz_height, nz_height_coords) %>%
##   st_drop_geometry()
## write.csv(nz_height2, "nz_height.csv")

library(raster)
library(spDataLarge)
nlcd
landsat_path = system.file("raster/landsat.tif", package = "spDataLarge")
landsat = stack(landsat_path)

## writeRaster(nlcd, filename = "nlcd1.tif")
## writeRaster(nlcd, filename = "nlcd2.tif", datatype = "INT1U")
## writeRaster(nlcd, filename = "nlcd3.tif", options = c("COMPRESS=DEFLATE"))
## writeRaster(nlcd, filename = "nlcd4.tif", datatype = "INT1U",
##             options = c("COMPRESS=DEFLATE"))

## writeRaster(landsat, filename = "landsat1.tif", bylayer = FALSE)
## writeRaster(landsat, filename = "landsat2.tif", bylayer = TRUE)
## names(landsat) = c("band2", "band3", "band4", "band5")
## writeRaster(landsat, filename = "landsat3.tif", bylayer = TRUE, suffix = "names")

srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
