library(raster)
library(spDataLarge)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

srtm2 = srtm + 1000

srtm3 = srtm - cellStats(srtm, min)

srtm4 = srtm - cellStats(srtm, median)



rcl = matrix(c(0, 1500, 1, 1500, 2000, 2, 2000, 9999, 3),
             ncol = 3, byrow = TRUE)
srtm_recl = reclassify(srtm, rcl = rcl)



landsat_path = system.file("raster/landsat.tif", package = "spDataLarge")
landsat = stack(landsat_path)

ndvi_fun = function(nir, red){
  (nir - red) / (nir + red)
}
ndvi = overlay(landsat[[4]], landsat[[3]], fun = ndvi_fun)



srtm_focal = focal(srtm, 
                   w = matrix(1, nrow = 3, ncol = 3), 
                   fun = var)





library(spData)
elev_by_grain = zonal(elev, grain, fun = "mean")
elev_by_grain

cellStats(srtm, stat = "mean")
cellStats(srtm, stat = "sd")

srtm[100:300, 200:400] = NA



srtm_dist = distance(srtm)
