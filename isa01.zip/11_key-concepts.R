options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, echo = FALSE, fig.height = 5)
knitr::opts_chunk$set(root.dir = normalizePath("."))
