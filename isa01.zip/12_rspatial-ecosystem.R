options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

# citation()
citation("tmap")
