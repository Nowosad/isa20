library(sf)
library(raster)
library(spData)
library(spDataLarge)
nz
nz_elev
otago = subset(nz, Name == "Otago")



nz_elev_cropped = crop(nz_elev, otago)



nz_elev_masked = mask(nz_elev, otago)



nz_elev_cropped = crop(nz_elev, otago)
nz_elev_masked2 = mask(nz_elev_cropped, otago)



## srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
## zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"))
## zion = st_transform(zion, projection(srtm))
