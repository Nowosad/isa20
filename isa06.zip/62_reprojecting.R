library(sf)
zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)
data(zion_points, package = "spDataLarge")





zion_points2a = st_transform(zion_points,
                             crs = 26912)

zion_points2b = st_transform(zion_points,
                             crs = "+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs")

zion_points3 = st_transform(zion_points, st_crs(zion))
zion_points3





library(raster)
cat_raster = raster(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
projection(cat_raster)

unique(cat_raster)



wgs84 = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"
cat_raster_wgs84 = projectRaster(cat_raster, crs = wgs84, method = "ngb")





con_raster = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
projection(con_raster)

# hist(con_raster)



equalarea = "+proj=laea +lat_0=37.32 +lon_0=-113.04"
con_raster_ea = projectRaster(con_raster, crs = equalarea, method = "bilinear")
projection(con_raster_ea)





srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)





zion2 = st_transform(zion, projection(srtm))





zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)



zion_center = zion %>% 
  st_centroid() %>% 
  st_transform(4326) %>% 
  st_coordinates()

new_crs = paste0("+proj=laea", 
                " +lat_0=", zion_center[, 2],
                " +lon_0=", zion_center[, 1])
new_crs

zion2 = st_transform(zion, new_crs)













library(spData)
us_states



us_states_center = us_states %>% 
  st_union() %>% 
  st_centroid() %>% 
  st_transform(4326) %>% 
  st_coordinates()

new_crs3 = paste0("+proj=lcc", 
                " +lat_0=", us_states_center[, 2],
                " +lon_0=", us_states_center[, 1],
                " +lat_1=", us_states_center[, 2])
new_crs3

us_states2 = st_transform(us_states, new_crs3)



vector_filepath = system.file("vector/zion.gpkg", package = "spDataLarge")
new_vector = st_read(vector_filepath)
st_crs(new_vector) # get CRS
new_vector = st_set_crs(new_vector, 4326) # set CRS

raster_filepath = system.file("raster/srtm.tif", package = "spDataLarge")
new_raster = raster(raster_filepath)
projection(new_raster) # get CRS
projection(new_raster) = "+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 
                            +units=m +no_defs" # set CRS
projection(new_raster) = "+init=epsg:26912" # set CRS
